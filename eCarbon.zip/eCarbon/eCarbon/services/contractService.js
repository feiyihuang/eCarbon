const { ethers } = require('ethers');

const CONTRACT_ABI = [
        {
            "inputs": [],
            "stateMutability": "nonpayable",
            "type": "constructor"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "user",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "coins",
                    "type": "uint256"
                },
                {
                    "indexed": false,
                    "internalType": "string",
                    "name": "item",
                    "type": "string"
                }
            ],
            "name": "CarbonCoinRedeemed",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "from",
                    "type": "address"
                },
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "to",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "amount",
                    "type": "uint256"
                }
            ],
            "name": "CarbonCoinsTransferred",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "from",
                    "type": "address"
                },
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "to",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "points",
                    "type": "uint256"
                }
            ],
            "name": "CarbonPointsTransferred",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "user",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "points",
                    "type": "uint256"
                }
            ],
            "name": "CarbonPointsUpdated",
            "type": "event"
        },
        {
            "inputs": [],
            "name": "createAccount",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "to",
                    "type": "address"
                },
                {
                    "internalType": "uint256",
                    "name": "amount",
                    "type": "uint256"
                }
            ],
            "name": "issueCarbonCoin",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "points",
                    "type": "uint256"
                }
            ],
            "name": "redeemCarbonCoins",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "carbonCoins",
                    "type": "uint256"
                },
                {
                    "internalType": "string",
                    "name": "product",
                    "type": "string"
                }
            ],
            "name": "redeemProduct",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "to",
                    "type": "address"
                },
                {
                    "internalType": "uint256",
                    "name": "points",
                    "type": "uint256"
                }
            ],
            "name": "transferCarbonPoints",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "user",
                    "type": "address"
                },
                {
                    "internalType": "uint256",
                    "name": "points",
                    "type": "uint256"
                }
            ],
            "name": "updateCarbonPoints",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "",
                    "type": "address"
                }
            ],
            "name": "carbonBalances",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "",
                    "type": "address"
                }
            ],
            "name": "carbonPoints",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "user",
                    "type": "address"
                }
            ],
            "name": "getCarbonCoinBalance",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "user",
                    "type": "address"
                }
            ],
            "name": "getCarbonPointBalance",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "",
                    "type": "address"
                }
            ],
            "name": "lastTransferTime",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "owner",
            "outputs": [
                {
                    "internalType": "address",
                    "name": "",
                    "type": "address"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "totalSupply",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "transferLimit",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "",
                    "type": "address"
                }
            ],
            "name": "transferredPoints",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        }
];
//每次部署智能合约都需要更新合约地址
const CONTRACT_ADDRESS = "0x3F32d8C5839B56D3143DE4e4a278b2243DAe74bD";
const RPC_URL = "http://127.0.0.1:8545";

class ContractService {
    constructor() {
        this.provider = new ethers.JsonRpcProvider(RPC_URL);
        this.contract = new ethers.Contract(
            CONTRACT_ADDRESS,
            CONTRACT_ABI,
            this.provider
        );
    }

    // 获取 Ganache 的所有测试账户
    async getTestAccounts() {
        try {
            const accounts = await this.provider.send('eth_accounts', []);
            return accounts;
        } catch (error) {
            throw new Error(`获取测试账户失败: ${error.message}`);
        }
    }

    // 获取合约 owner 地址
    async getOwnerAddress() {
        try {
            const result = await this.provider.call({
                to: CONTRACT_ADDRESS,
                data: this.contract.interface.encodeFunctionData('owner', [])
            });
            const owner = this.contract.interface.decodeFunctionResult('owner', result);
            return owner[0];
        } catch (error) {
            throw new Error(`获取 owner 地址失败: ${error.message}`);
        }
    }

    // 发行碳币
    async issueCarbonCoin(toAddress, amount) {
        try {
            // 获取当前可用的账户列表
            const accounts = await this.getTestAccounts();
            // 获取合约 owner 地址
            const ownerAddress = await this.getOwnerAddress();
            
            // 确保 owner 地址在可用账户列表中
            if (!accounts.includes(ownerAddress.toLowerCase())) {
                throw new Error('合约 owner 地址不在可用账户列表中');
            }

            const data = this.contract.interface.encodeFunctionData('issueCarbonCoin', [toAddress, amount]);
            const tx = await this.provider.send('eth_sendTransaction', [{
                from: ownerAddress,
                to: CONTRACT_ADDRESS,
                data: data
            }]);
            return tx;
        } catch (error) {
            console.error('发行碳币错误:', error);
            throw new Error(`发行碳币失败: ${error.message}`);
        }
    }

    // 创建账户方法 - 返回更详细的信息
    async createAccount() {
        try {
            // 获取所有可用的测试账户
            const accounts = await this.getTestAccounts();
            
            // 随机选择一个账户
            const randomIndex = Math.floor(Math.random() * accounts.length);
            const address = accounts[randomIndex];

            // 调用合约的 createAccount 方法
            const data = this.contract.interface.encodeFunctionData('createAccount', []);
            const tx = await this.provider.send('eth_sendTransaction', [{
                from: address,
                to: CONTRACT_ADDRESS,
                data: data
            }]);

            // 返回更详细的账户信息
            return {
                transactionHash: tx,
                blockchainAddress: address,  // 区块链地址
                message: '区块链账户创建成功'
            };
        } catch (error) {
            throw new Error(`创建区块链账户失败: ${error.message}`);
        }
    }

    // 更新碳积分
    async updateCarbonPoints(userAddress, points) {
        try {
            // 获取合约拥有者地址
            const ownerAddress = await this.getOwnerAddress();
            
            // 使用合约拥有者地址发送交易
            const data = this.contract.interface.encodeFunctionData('updateCarbonPoints', [userAddress, points]);
            const tx = await this.provider.send('eth_sendTransaction', [{
                from: ownerAddress,  // 使用获取到的 owner 地址
                to: CONTRACT_ADDRESS,
                data: data
            }]);
            return tx;
        } catch (error) {
            console.error('更新碳积分错误:', error);
            throw new Error(`更新碳积分失败: ${error.message}`);
        }
    }

    // 转赠碳积分
    async transferCarbonPoints(from, to, points) {
        try {
            const data = this.contract.interface.encodeFunctionData('transferCarbonPoints', [to, points]);
            const tx = await this.provider.send('eth_sendTransaction', [{
                from: from,
                to: CONTRACT_ADDRESS,
                data: data
            }]);
            return tx;
        } catch (error) {
            throw new Error(`转赠碳积分失败: ${error.message}`);
        }
    }

    // 查询余额（只读方法保持不变）
    async getCarbonCoinBalance(address) {
        try {
            // 确保地址格式正确
            if (!address || !address.startsWith('0x')) {
                throw new Error('无效的地址格式');
            }

            // 调用合约方法
            const data = this.contract.interface.encodeFunctionData('getCarbonCoinBalance', [address]);
            const result = await this.provider.call({
                to: CONTRACT_ADDRESS,
                data: data
            });

            // 解码结果
            if (result === '0x') {
                return "0"; // 如果没有余额，返回 0
            }

            const coins = this.contract.interface.decodeFunctionResult('getCarbonCoinBalance', result);
            return coins[0].toString();
        } catch (error) {
            console.error('查询碳币余额错误:', error);
            return "0"; // 出错时返回 0，而不是抛出错误
        }
    }

    // 查询碳积分余额
    async getCarbonPointBalance(address) {
        try {
            // 确保地址格式正确
            if (!address || !address.startsWith('0x')) {
                throw new Error('无效的地址格式');
            }

            // 调用合约方法
            const data = this.contract.interface.encodeFunctionData('getCarbonPointBalance', [address]);
            const result = await this.provider.call({
                to: CONTRACT_ADDRESS,
                data: data
            });

            // 解码结果
            if (result === '0x') {
                return "0"; // 如果没有余额，返回 0
            }

            const points = this.contract.interface.decodeFunctionResult('getCarbonPointBalance', result);
            return points[0].toString();
        } catch (error) {
            console.error('查询碳积分余额错误:', error);
            throw new Error(`查询碳积分余额失败: ${error.message}`);
        }
    }

    // 兑换碳币方法
    async redeemCarbonCoins(from, points) {
        try {
            // 获取当前可用的账户列表
            const accounts = await this.getTestAccounts();
            
            // 确保用户地址在可用账户列表中
            if (!accounts.includes(from.toLowerCase())) {
                throw new Error('用户地址不在可用账户列表中');
            }

            // 调用合约的 redeemCarbonCoins 方法
            const data = this.contract.interface.encodeFunctionData('redeemCarbonCoins', [points]);
            const tx = await this.provider.send('eth_sendTransaction', [{
                from: from,
                to: CONTRACT_ADDRESS,
                data: data
            }]);

            return {
                transactionHash: tx,
                points: points,
                estimatedCoins: (Number(points) / 10).toString(), // 10积分兑换1个碳币
                message: '碳积分兑换成功'
            };
        } catch (error) {
            console.error('兑换碳币错误:', error);
            throw new Error(`兑换碳币失败: ${error.message}`);
        }
    }

    // 修改兑换商品方法
    async redeemProduct(userAddress, carbonPoints, productName) {
        try {
            // 确保地址格式正确
            if (!userAddress || !userAddress.startsWith('0x')) {
                throw new Error('无效的地址格式');
            }

            // 先检查用户的碳积分余额
            const currentPoints = await this.getCarbonPointBalance(userAddress);
            if (Number(currentPoints) < carbonPoints) {
                throw new Error('碳积分余额不足');
            }

            // 调用合约的 redeemCarbonCoins 方法先扣除积分
            const redeemData = this.contract.interface.encodeFunctionData('redeemCarbonCoins', [
                carbonPoints
            ]);

            await this.provider.send('eth_sendTransaction', [{
                from: userAddress,
                to: CONTRACT_ADDRESS,
                data: redeemData
            }]);

            // 然后调用 redeemProduct 方法记录兑换
            const productData = this.contract.interface.encodeFunctionData('redeemProduct', [
                carbonPoints,
                productName
            ]);

            const tx = await this.provider.send('eth_sendTransaction', [{
                from: userAddress,
                to: CONTRACT_ADDRESS,
                data: productData
            }]);

            return tx;
        } catch (error) {
            console.error('商品兑换错误:', error);
            throw new Error(`商品兑换失败: ${error.message}`);
        }
    }
}

module.exports = new ContractService(); 