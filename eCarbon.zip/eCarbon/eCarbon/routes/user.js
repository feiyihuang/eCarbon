const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();
const User = require('../models/User');
const UserTask = require('../models/UserTask');
const Transaction = require('../models/Transaction');
const CarbonFootprint = require('../models/CarbonFootprint');
const contractService = require('../services/contractService');

// 获取所有用户
router.get('/get-all-users', async (req, res) => {
    try {
        const users = await User.find({}, 'phone_number _id');
        res.json({
            success: true,
            data: users
        });
    } catch (error) {
        console.error('获取用户列表失败:', error);
        res.status(500).json({
            success: false,
            message: '获取用户列表失败'
        });
    }
});

// 用户注册
router.post('/register', async (req, res) => {
    try {
        const { phone_number, name, password, role = 0 } = req.body;
        
        // 输入验证
        if (!phone_number || !name || !password) {
            return res.status(400).json({
                success: false,
                message: '所有字段都是必填的'
            });
        }

        // 检查手机号是否已存在
        const existingUser = await User.findOne({ phone_number });
        if (existingUser) {
            return res.status(400).json({
                success: false,
                message: '该手机号已被注册'
            });
        }

        // 创建区块链账户
        const blockchainAccount = await contractService.createAccount();
        console.log('创建的区块链账户:', blockchainAccount); // 添加日志

        // 创建新用户，包含区块链地址
        const newUser = new User({
            phone_number,
            name,
            password,
            blockchain_address: blockchainAccount.blockchainAddress,
            registration_date: new Date(),
            role
        });

        const savedUser = await newUser.save();
        console.log('保存的用户信息:', savedUser); // 添加日志
        
        // 确保返回所有必要的信息
        res.status(201).json({
            success: true,
            data: {
                user_id: savedUser._id,
                phone_number: savedUser.phone_number,
                name: savedUser.name,
                blockchain_address: savedUser.blockchain_address, // 确保返回区块链地址
                registration_date: savedUser.registration_date,
                role: savedUser.role,  // 返回用户角色
                transaction_hash: blockchainAccount.transactionHash, // 添加交易哈希
                message: '用户注册成功，区块链账户已创建'
            }
        });
    } catch (error) {
        console.error('用户注册失败:', error);
        res.status(500).json({
            success: false,
            message: '用户注册失败',
            error: error.message
        });
    }
});

// 更新用户信息
router.put('/update-user', async (req, res) => {
    try {
        const { phone_number, name, password } = req.body;
        
        const user = await User.findOne({ phone_number });
        if (!user) {
            return res.status(404).json({
                success: false,
                message: '用户不存在'
            });
        }

        if (name) user.name = name;
        if (password) user.password = password;

        const updatedUser = await user.save();

        res.json({
            success: true,
            data: {
                user_id: updatedUser._id,
                phone_number: updatedUser.phone_number,
                name: updatedUser.name
            }
        });
    } catch (error) {
        console.error('更新用户信息失败:', error);
        res.status(500).json({
            success: false,
            message: '更新用户信息失败'
        });
    }
});

// 注销用户
router.post('/delete-user', async (req, res) => {
    try {
        const { account } = req.body;
        
        const result = await User.findOneAndDelete({ phone_number: account });
        if (!result) {
            return res.status(404).json({
                success: false,
                message: '用户不存在'
            });
        }

        res.json({
            success: true,
            message: '用户注销成功'
        });
    } catch (error) {
        console.error('用户注销失败:', error);
        res.status(500).json({
            success: false,
            message: '用户注销失败'
        });
    }
});

// 查询特定用户信息
router.get('/get-user', async (req, res) => {
    try {
        const { user_id } = req.query;
        
        // 验证用户ID
        if (!mongoose.Types.ObjectId.isValid(user_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的用户ID'
            });
        }

        // 查询用户基本信息
        const user = await User.findById(user_id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: '未找到指定用户'
            });
        }

        // 查询用户的区块链信息
        const carbonPoints = await contractService.getCarbonPointBalance(user.blockchain_address);
        const carbonCoins = await contractService.getCarbonCoinBalance(user.blockchain_address);

        // 查询用户的任务信息
        const tasks = await UserTask.find({ user_id });

        // 查询用户的交易记录
        const transactions = await Transaction.find({ user_id });

        // 查询用户的碳足迹记录
        const carbonFootprints = await CarbonFootprint.find({ user_id });

        // 组装完整的用户信息
        const userDetails = {
            // 基本信息
            user_id: user._id,
            phone_number: user.phone_number,
            name: user.name,
            blockchain_address: user.blockchain_address,
            registration_date: user.registration_date,
            role: user.role,

            // 区块链信息
            carbon_points: carbonPoints,
            carbon_coins: carbonCoins,

            // 任务信息
            tasks: tasks.map(task => ({
                user_task_id: task._id,
                task_type_id: task.task_type_id,
                task_name: task.task_name,
                reward: task.reward,
                progress: task.progress,
                completed: task.completed,
                rewarded: task.rewarded,
                created_at: task.created_at,
                updated_at: task.updated_at
            })),

            // 交易记录
            transactions: transactions.map(trans => ({
                transaction_id: trans._id,
                product_name: trans.product_name,
                carbon_points_cost: trans.carbon_points_cost,
                quantity: trans.quantity,
                transaction_time: trans.transaction_time
            })),

            // 碳足迹记录
            carbon_footprints: carbonFootprints.map(footprint => ({
                footprint_id: footprint._id,
                event_type: footprint.event_type,
                carbon_emission: footprint.carbon_emission,
                created_at: footprint.created_at
            })),

            // 统计信息
            statistics: {
                total_tasks: tasks.length,
                completed_tasks: tasks.filter(t => t.progress === 100).length,
                total_transactions: transactions.length,
                total_carbon_footprints: carbonFootprints.length
            }
        };

        res.json({
            success: true,
            data: userDetails
        });

    } catch (error) {
        console.error('查询用户信息失败:', error);
        res.status(500).json({
            success: false,
            message: '查询用户信息失败',
            error: error.message
        });
    }
});

// 用户登录
router.post('/login', async (req, res) => {
    try {
        const { phone_number, password } = req.body;
        
        // 查找用户
        const user = await User.findOne({ phone_number });
        if (!user) {
            return res.status(401).json({
                success: false,
                message: '用户不存在'
            });
        }

        // 验证密码
        const isMatch = await user.comparePassword(password);
        if (!isMatch) {
            return res.status(401).json({
                success: false,
                message: '密码错误'
            });
        }

        // 生成 JWT token
        const token = jwt.sign(
            { user_id: user._id },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        res.json({
            success: true,
            data: {
                user_id: user._id,
                phone_number: user.phone_number,
                name: user.name,
                blockchain_address: user.blockchain_address,
                role: user.role,  // 返回用户角色
                message: '登录成功'
            }
        });
    } catch (error) {
        console.error('登录失败:', error);
        res.status(500).json({
            success: false,
            message: '登录失败'
        });
    }
});

module.exports = router; 