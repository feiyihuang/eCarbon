const express = require('express');
const router = express.Router();
const UserTask = require('../models/UserTask');
const mongoose = require('mongoose');
const User = require('../models/User');
const contractService = require('../services/contractService');

// 查询用户的所有任务
router.get('/get-user-tasks/:user_id', async (req, res) => {
    try {
        const { user_id } = req.params;

        // 验证 user_id 格式
        if (!mongoose.Types.ObjectId.isValid(user_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的用户ID'
            });
        }

        // 查询该用户的所有任务
        const userTasks = await UserTask.find({ user_id });

        const formattedTasks = userTasks.map(task => ({
            user_task_id: task._id,
            user_id: task.user_id,
            task_type_id: task.task_type_id,
            task_name: task.task_name,
            reward: task.reward,
            progress: task.progress,
            created_at: task.created_at,
            updated_at: task.updated_at
        }));

        res.json({
            success: true,
            data: formattedTasks
        });
    } catch (error) {
        console.error('查询用户任务失败:', error);
        res.status(500).json({
            success: false,
            message: '查询用户任务失败',
            error: error.message
        });
    }
});

// 添加用户任务关联
router.post('/add-user-task', async (req, res) => {
    try {
        const { user_id, task_type_id, task_name, reward, progress } = req.body;

        // 验证必要字段
        if (!user_id || !task_type_id || !task_name || reward === undefined || progress === undefined) {
            return res.status(400).json({
                success: false,
                message: '所有字段都是必填项'
            });
        }

        // 验证 ID 格式
        if (!mongoose.Types.ObjectId.isValid(user_id) || !mongoose.Types.ObjectId.isValid(task_type_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的ID格式'
            });
        }

        // 验证进度范围
        if (progress < 0 || progress > 100) {
            return res.status(400).json({
                success: false,
                message: '进度必须在0-100之间'
            });
        }

        // 创建新的用户任务关联
        const newUserTask = new UserTask({
            user_id,
            task_type_id,
            task_name,
            reward,
            progress
        });

        const savedUserTask = await newUserTask.save();

        res.status(201).json({
            success: true,
            data: {
                user_task_id: savedUserTask._id,
                user_id: savedUserTask.user_id,
                task_type_id: savedUserTask.task_type_id,
                task_name: savedUserTask.task_name,
                reward: savedUserTask.reward,
                progress: savedUserTask.progress,
                message: '用户任务关联创建成功'
            }
        });
    } catch (error) {
        console.error('添加用户任务关联失败:', error);
        res.status(500).json({
            success: false,
            message: '添加用户任务关联失败',
            error: error.message
        });
    }
});

// 删除用户任务关联
router.delete('/delete-user-task', async (req, res) => {
    try {
        const { user_task_id } = req.body;

        // 验证 ID 格式
        if (!mongoose.Types.ObjectId.isValid(user_task_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的用户任务关联ID'
            });
        }

        // 查找任务关联记录
        const userTask = await UserTask.findById(user_task_id);
        if (!userTask) {
            return res.status(404).json({
                success: false,
                message: '未找到指定的用户任务关联'
            });
        }

        // 检查任务是否已完成或已获得奖励
        if (userTask.completed || userTask.rewarded) {
            return res.status(400).json({
                success: false,
                message: '已完成或已获得奖励的任务不能删除'
            });
        }

        // 删除任务关联
        const deletedUserTask = await UserTask.findByIdAndDelete(user_task_id);

        res.json({
            success: true,
            data: {
                user_task_id: deletedUserTask._id,
                task_name: deletedUserTask.task_name,
                message: '用户任务关联删除成功'
            }
        });
    } catch (error) {
        console.error('删除用户任务关联失败:', error);
        res.status(500).json({
            success: false,
            message: '删除用户任务关联失败',
            error: error.message
        });
    }
});

// 更新用户任务关联
router.put('/update-user-task', async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        const { user_task_id, user_id, task_type_id, task_name, reward, progress } = req.body;

        // 验证必要字段
        if (!user_task_id || !user_id || !task_type_id || !task_name || reward === undefined || progress === undefined) {
            return res.status(400).json({
                success: false,
                message: '所有字段都是必填项'
            });
        }

        // 验证 ID 格式
        if (!mongoose.Types.ObjectId.isValid(user_task_id) || 
            !mongoose.Types.ObjectId.isValid(user_id) || 
            !mongoose.Types.ObjectId.isValid(task_type_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的ID格式'
            });
        }

        // 验证进度范围
        if (progress < 0 || progress > 100) {
            return res.status(400).json({
                success: false,
                message: '进度必须在0-100之间'
            });
        }

        // 获取当前任务状态
        const currentTask = await UserTask.findById(user_task_id);
        if (!currentTask) {
            return res.status(404).json({
                success: false,
                message: '未找到指定的用户任务关联'
            });
        }

        // 检查是否已经获得奖励
        if (currentTask.rewarded) {
            return res.status(400).json({
                success: false,
                message: '该任务已经获得奖励'
            });
        }

        // 准备更新数据
        const updateData = {
            user_id,
            task_type_id,
            task_name,
            reward,
            progress,
            updated_at: new Date()
        };

        // 如果进度达到100%，设置completed为true
        if (progress === 100) {
            updateData.completed = true;
        }

        // 查找并更新用户任务关联
        const updatedUserTask = await UserTask.findByIdAndUpdate(
            user_task_id,
            updateData,
            { new: true }
        );

        // 如果任务完成且未获得奖励，发放奖励
        if (progress === 100 && !currentTask.rewarded) {
            // 获取用户信息
            const user = await User.findById(user_id);
            if (!user) {
                throw new Error('用户不存在');
            }

            // 发放碳积分奖励
            await contractService.updateCarbonPoints(user.blockchain_address, reward);

            // 更新任务的rewarded状态
            updatedUserTask.rewarded = true;
            await updatedUserTask.save();
        }

        await session.commitTransaction();
        session.endSession();

        res.json({
            success: true,
            data: {
                user_task_id: updatedUserTask._id,
                user_id: updatedUserTask.user_id,
                task_type_id: updatedUserTask.task_type_id,
                task_name: updatedUserTask.task_name,
                reward: updatedUserTask.reward,
                progress: updatedUserTask.progress,
                completed: updatedUserTask.completed,
                rewarded: updatedUserTask.rewarded,
                updated_at: updatedUserTask.updated_at,
                message: progress === 100 ? '任务完成，奖励已发放' : '任务进度已更新'
            }
        });
    } catch (error) {
        await session.abortTransaction();
        session.endSession();

        console.error('更新用户任务关联失败:', error);
        res.status(500).json({
            success: false,
            message: '更新用户任务关联失败',
            error: error.message
        });
    }
});

module.exports = router; 