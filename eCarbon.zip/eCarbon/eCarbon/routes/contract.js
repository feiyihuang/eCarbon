const express = require('express');
const router = express.Router();
const contractService = require('../services/contractService');

// 创建账户接口 - 不需要输入地址
router.post('/create-account', async (req, res) => {
    try {
        const result = await contractService.createAccount();
        res.json({
            success: true,
            data: {
                transactionHash: result.transactionHash,
                accountAddress: result.accountAddress,
                privateKey: result.privateKey,  // 注意：实际生产环境中要谨慎处理私钥
                message: '账户创建成功'
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '创建账户失败',
            error: error.message
        });
    }
});

// 发行碳币
router.post('/issue-coin', async (req, res) => {
    try {
        const { toAddress, amount } = req.body;
        const result = await contractService.issueCarbonCoin(toAddress, amount);
        res.json({
            success: true,
            data: result
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '发行碳币失败',
            error: error.message
        });
    }
});

// 更新碳积分
router.put('/update-points', async (req, res) => {
    try {
        const { userAddress, points } = req.body;
        const result = await contractService.updateCarbonPoints(userAddress, points);
        res.json({
            success: true,
            data: result
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '更新碳积分失败',
            error: error.message
        });
    }
});

// 转赠碳积分
router.post('/transfer-points', async (req, res) => {
    try {
        const { from, to, points } = req.body;
        const result = await contractService.transferCarbonPoints(from, to, points);
        res.json({
            success: true,
            data: result
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '转赠碳积分失败',
            error: error.message
        });
    }
});

// 查询用户碳币余额
router.get('/coin-balance/:address', async (req, res) => {
    try {
        const balance = await contractService.getCarbonCoinBalance(req.params.address);
        res.json({
            success: true,
            data: balance
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '查询碳币余额失败',
            error: error.message
        });
    }
});

// 查询用户碳积分余额
router.get('/point-balance/:address', async (req, res) => {
    try {
        const points = await contractService.getCarbonPointBalance(req.params.address);
        res.json({
            success: true,
            data: points
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '查询碳积分余额失败',
            error: error.message
        });
    }
});

// 获取合约 owner 地址的路由
router.get('/owner', async (req, res) => {
    try {
        const ownerAddress = await contractService.getOwnerAddress();
        res.json({
            success: true,
            data: {
                owner: ownerAddress
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '获取 owner 地址失败',
            error: error.message
        });
    }
});

// 兑换碳币路由
router.post('/redeem-coins', async (req, res) => {
    try {
        const { from, points } = req.body;
        const result = await contractService.redeemCarbonCoins(from, points);
        res.json({
            success: true,
            data: result
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '兑换碳币失败',
            error: error.message
        });
    }
});

module.exports = router; 