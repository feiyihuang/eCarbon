const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();
const Product = require('../models/Product');

// 查询所有商品
router.get('/get-products', async (req, res) => {
    try {
        const products = await Product.find({})
            .select('name price quantity created_at updated_at')
            .sort({ created_at: -1 });
        
        const formattedProducts = products.map(product => ({
            product_id: product._id,
            name: product.name,
            price: product.price,
            quantity: product.quantity,
            created_at: product.created_at,
            updated_at: product.updated_at
        }));

        res.json({
            success: true,
            data: {
                total: formattedProducts.length,
                products: formattedProducts
            }
        });
    } catch (error) {
        console.error('查询商品失败:', error);
        res.status(500).json({
            success: false,
            message: '查询商品失败',
            error: error.message
        });
    }
});

// 查询单个商品 - 使用查询参数而不是路径参数
router.get('/get-product', async (req, res) => {
    try {
        const { product_id } = req.query;  // 从查询参数获取 product_id

        // 验证商品ID格式
        if (!mongoose.Types.ObjectId.isValid(product_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的商品ID'
            });
        }

        const product = await Product.findById(product_id);
        
        if (!product) {
            return res.status(404).json({
                success: false,
                message: '未找到指定商品'
            });
        }

        res.json({
            success: true,
            data: {
                product_id: product._id,
                name: product.name,
                price: product.price,
                quantity: product.quantity,
                created_at: product.created_at,
                updated_at: product.updated_at
            }
        });
    } catch (error) {
        console.error('查询商品失败:', error);
        res.status(500).json({
            success: false,
            message: '查询商品失败',
            error: error.message
        });
    }
});

module.exports = router; 