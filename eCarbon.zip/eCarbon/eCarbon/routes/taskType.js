const express = require('express');
const router = express.Router();
const TaskType = require('../models/TaskType');
const mongoose = require('mongoose');

// 查询所有任务种类
router.get('/get-task-types', async (req, res) => {
    try {
        const taskTypes = await TaskType.find({}, 'name reward');
        
        const formattedTaskTypes = taskTypes.map(task => ({
            id: task._id,
            name: task.name,
            reward: task.reward
        }));

        res.json({
            success: true,
            data: formattedTaskTypes
        });
    } catch (error) {
        console.error('查询任务种类失败:', error);
        res.status(500).json({
            success: false,
            message: '查询任务种类失败',
            error: error.message
        });
    }
});

// 上传任务种类
router.post('/add-task-type', async (req, res) => {
    try {
        const { name, reward } = req.body;

        // 验证必要字段
        if (!name || reward === undefined) {
            return res.status(400).json({
                success: false,
                message: '任务名称和奖励都是必填项'
            });
        }

        // 验证奖励是否为非负数
        if (reward < 0) {
            return res.status(400).json({
                success: false,
                message: '奖励必须是非负数'
            });
        }

        // 检查任务名称是否已存在
        const existingTask = await TaskType.findOne({ name });
        if (existingTask) {
            return res.status(400).json({
                success: false,
                message: '该任务名称已存在'
            });
        }

        // 创建新任务种类
        const newTaskType = new TaskType({
            name,
            reward
        });

        const savedTaskType = await newTaskType.save();

        res.status(201).json({
            success: true,
            data: {
                task_type_id: savedTaskType._id,
                message: '任务种类添加成功'
            }
        });
    } catch (error) {
        console.error('添加任务种类失败:', error);
        res.status(500).json({
            success: false,
            message: '添加任务种类失败',
            error: error.message
        });
    }
});

// 删除任务种类
router.delete('/delete-task-type', async (req, res) => {
    try {
        const { task_type_id } = req.body;

        // 验证 ID 格式
        if (!mongoose.Types.ObjectId.isValid(task_type_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的任务种类ID'
            });
        }

        // 查找并删除任务种类
        const deletedTaskType = await TaskType.findByIdAndDelete(task_type_id);

        if (!deletedTaskType) {
            return res.status(404).json({
                success: false,
                message: '未找到指定的任务种类'
            });
        }

        res.json({
            success: true,
            message: '任务种类删除成功'
        });
    } catch (error) {
        console.error('删除任务种类失败:', error);
        res.status(500).json({
            success: false,
            message: '删除任务种类失败',
            error: error.message
        });
    }
});

// 更新任务种类
router.put('/update-task-type', async (req, res) => {
    try {
        const { task_type_id, name, reward } = req.body;

        // 验证必要字段
        if (!task_type_id || !name || reward === undefined) {
            return res.status(400).json({
                success: false,
                message: '任务种类ID、名称和奖励都是必填项'
            });
        }

        // 验证 ID 格式
        if (!mongoose.Types.ObjectId.isValid(task_type_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的任务种类ID'
            });
        }

        // 验证奖励是否为非负数
        if (reward < 0) {
            return res.status(400).json({
                success: false,
                message: '奖励必须是非负数'
            });
        }

        // 检查新名称是否与其他任务冲突
        const existingTask = await TaskType.findOne({ 
            name, 
            _id: { $ne: task_type_id } 
        });
        if (existingTask) {
            return res.status(400).json({
                success: false,
                message: '该任务名称已存在'
            });
        }

        // 查找并更新任务种类
        const updatedTaskType = await TaskType.findByIdAndUpdate(
            task_type_id,
            { name, reward },
            { new: true }
        );

        if (!updatedTaskType) {
            return res.status(404).json({
                success: false,
                message: '未找到指定的任务种类'
            });
        }

        res.json({
            success: true,
            data: {
                task_type_id: updatedTaskType._id,
                name: updatedTaskType.name,
                reward: updatedTaskType.reward,
                message: '任务种类更新成功'
            }
        });
    } catch (error) {
        console.error('更新任务种类失败:', error);
        res.status(500).json({
            success: false,
            message: '更新任务种类失败',
            error: error.message
        });
    }
});

module.exports = router; 