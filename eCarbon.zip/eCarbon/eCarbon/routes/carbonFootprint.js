const express = require('express');
const router = express.Router();
const CarbonFootprint = require('../models/CarbonFootprint');
const mongoose = require('mongoose');

// 查询碳足迹
router.get('/get-footprints/:user_id', async (req, res) => {
    try {
        const { user_id } = req.params;

        // 验证 user_id 格式
        if (!mongoose.Types.ObjectId.isValid(user_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的用户ID'
            });
        }

        // 查询该用户的所有碳足迹
        const footprints = await CarbonFootprint.find({ user_id });

        // 格式化返回数据
        const formattedFootprints = footprints.map(fp => ({
            id: fp._id,
            carbon_footprint: {
                event_type: fp.event_type,
                carbon_emission: fp.carbon_emission
            },
            created_at: fp.created_at
        }));

        res.json({
            success: true,
            data: formattedFootprints
        });
    } catch (error) {
        console.error('查询碳足迹失败:', error);
        res.status(500).json({
            success: false,
            message: '查询碳足迹失败',
            error: error.message
        });
    }
});

// 上传碳足迹
router.post('/add-footprint', async (req, res) => {
    try {
        const { user_id, carbon_footprint } = req.body;

        // 验证必要字段
        if (!user_id || !carbon_footprint || !carbon_footprint.event_type || !carbon_footprint.carbon_emission) {
            return res.status(400).json({
                success: false,
                message: '缺少必要字段'
            });
        }

        // 验证 user_id 格式
        if (!mongoose.Types.ObjectId.isValid(user_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的用户ID'
            });
        }

        // 创建新的碳足迹记录
        const newFootprint = new CarbonFootprint({
            user_id,
            event_type: carbon_footprint.event_type,
            carbon_emission: carbon_footprint.carbon_emission
        });

        const savedFootprint = await newFootprint.save();

        res.status(201).json({
            success: true,
            data: {
                footprint_id: savedFootprint._id,
                message: '碳足迹记录添加成功'
            }
        });
    } catch (error) {
        console.error('添加碳足迹失败:', error);
        res.status(500).json({
            success: false,
            message: '添加碳足迹失败',
            error: error.message
        });
    }
});

// 删除碳足迹
router.delete('/delete-footprint', async (req, res) => {
    try {
        const { user_id, footprint_id } = req.body;

        // 验证 ID 格式
        if (!mongoose.Types.ObjectId.isValid(user_id) || !mongoose.Types.ObjectId.isValid(footprint_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的ID格式'
            });
        }

        // 查找并删除碳足迹记录
        const deletedFootprint = await CarbonFootprint.findOneAndDelete({
            _id: footprint_id,
            user_id: user_id
        });

        if (!deletedFootprint) {
            return res.status(404).json({
                success: false,
                message: '未找到指定的碳足迹记录'
            });
        }

        res.json({
            success: true,
            message: '碳足迹记录删除成功'
        });
    } catch (error) {
        console.error('删除碳足迹失败:', error);
        res.status(500).json({
            success: false,
            message: '删除碳足迹失败',
            error: error.message
        });
    }
});

// 更新碳足迹
router.put('/update-footprint', async (req, res) => {
    try {
        const { user_id, footprint_id, event_type, carbon_emission } = req.body;

        // 验证必要字段
        if (!user_id || !footprint_id || !event_type || carbon_emission === undefined) {
            return res.status(400).json({
                success: false,
                message: '缺少必要字段'
            });
        }

        // 验证 ID 格式
        if (!mongoose.Types.ObjectId.isValid(user_id) || !mongoose.Types.ObjectId.isValid(footprint_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的ID格式'
            });
        }

        // 验证事件类型
        if (!['出行', '节能'].includes(event_type)) {
            return res.status(400).json({
                success: false,
                message: '无效的事件类型'
            });
        }

        // 查找并更新碳足迹记录
        const updatedFootprint = await CarbonFootprint.findOneAndUpdate(
            {
                _id: footprint_id,
                user_id: user_id
            },
            {
                event_type,
                carbon_emission
            },
            { new: true }  // 返回更新后的文档
        );

        if (!updatedFootprint) {
            return res.status(404).json({
                success: false,
                message: '未找到指定的碳足迹记录'
            });
        }

        res.json({
            success: true,
            data: {
                footprint_id: updatedFootprint._id,
                carbon_footprint: {
                    event_type: updatedFootprint.event_type,
                    carbon_emission: updatedFootprint.carbon_emission
                },
                updated_at: updatedFootprint.created_at,
                message: '碳足迹记录更新成功'
            }
        });
    } catch (error) {
        console.error('更新碳足迹失败:', error);
        res.status(500).json({
            success: false,
            message: '更新碳足迹失败',
            error: error.message
        });
    }
});

module.exports = router; 