const express = require('express');
const router = express.Router();
const Activity = require('../models/Activity');
const mongoose = require('mongoose');

// 查询所有活动
router.get('/get-activities', async (req, res) => {
    try {
        const activities = await Activity.find({}, 'name link');
        
        const formattedActivities = activities.map(activity => ({
            id: activity._id,
            name: activity.name,
            link: activity.link
        }));

        res.json({
            success: true,
            data: formattedActivities
        });
    } catch (error) {
        console.error('查询活动失败:', error);
        res.status(500).json({
            success: false,
            message: '查询活动失败',
            error: error.message
        });
    }
});

// 上传活动
router.post('/add-activity', async (req, res) => {
    try {
        const { name, link } = req.body;

        // 验证必要字段
        if (!name || !link) {
            return res.status(400).json({
                success: false,
                message: '活动名称和链接都是必填项'
            });
        }

        // 创建新活动
        const newActivity = new Activity({
            name,
            link
        });

        const savedActivity = await newActivity.save();

        res.status(201).json({
            success: true,
            data: {
                activity_id: savedActivity._id,
                message: '活动添加成功'
            }
        });
    } catch (error) {
        console.error('添加活动失败:', error);
        res.status(500).json({
            success: false,
            message: '添加活动失败',
            error: error.message
        });
    }
});

// 删除活动
router.delete('/delete-activity', async (req, res) => {
    try {
        const { activity_id } = req.body;

        // 验证 ID 格式
        if (!mongoose.Types.ObjectId.isValid(activity_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的活动ID'
            });
        }

        // 查找并删除活动
        const deletedActivity = await Activity.findByIdAndDelete(activity_id);

        if (!deletedActivity) {
            return res.status(404).json({
                success: false,
                message: '未找到指定的活动'
            });
        }

        res.json({
            success: true,
            message: '活动删除成功'
        });
    } catch (error) {
        console.error('删除活动失败:', error);
        res.status(500).json({
            success: false,
            message: '删除活动失败',
            error: error.message
        });
    }
});

// 更新活动
router.put('/update-activity', async (req, res) => {
    try {
        const { activity_id, name, link } = req.body;

        // 验证必要字段
        if (!activity_id || !name || !link) {
            return res.status(400).json({
                success: false,
                message: '活动ID、名称和链接都是必填项'
            });
        }

        // 验证 ID 格式
        if (!mongoose.Types.ObjectId.isValid(activity_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的活动ID'
            });
        }

        // 查找并更新活动
        const updatedActivity = await Activity.findByIdAndUpdate(
            activity_id,
            { name, link },
            { new: true }
        );

        if (!updatedActivity) {
            return res.status(404).json({
                success: false,
                message: '未找到指定的活动'
            });
        }

        res.json({
            success: true,
            data: {
                activity_id: updatedActivity._id,
                name: updatedActivity.name,
                link: updatedActivity.link,
                message: '活动更新成功'
            }
        });
    } catch (error) {
        console.error('更新活动失败:', error);
        res.status(500).json({
            success: false,
            message: '更新活动失败',
            error: error.message
        });
    }
});

module.exports = router; 