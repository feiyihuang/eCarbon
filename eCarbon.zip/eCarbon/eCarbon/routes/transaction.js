const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const Product = require('../models/Product');
const mongoose = require('mongoose');
const contractService = require('../services/contractService');

// 查询用户的所有交易
router.get('/get-user-transactions/:user_id', async (req, res) => {
    try {
        const { user_id } = req.params;

        // 验证 user_id 格式
        if (!mongoose.Types.ObjectId.isValid(user_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的用户ID'
            });
        }

        // 查询该用户的所有交易
        const transactions = await Transaction.find({ user_id });

        const formattedTransactions = transactions.map(trans => ({
            transaction_id: trans._id,
            product_id: trans.product_id,
            product_name: trans.product_name,
            carbon_points_cost: trans.carbon_points_cost,
            quantity: trans.quantity,
            transaction_time: trans.transaction_time
        }));

        res.json({
            success: true,
            data: formattedTransactions
        });
    } catch (error) {
        console.error('查询交易记录失败:', error);
        res.status(500).json({
            success: false,
            message: '查询交易记录失败',
            error: error.message
        });
    }
});

// 新增交易
router.post('/add-transaction', async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        const { 
            user_id, 
            product_id, 
            product_name, 
            carbon_points_cost, 
            quantity 
        } = req.body;

        // 验证必要字段
        if (!user_id || !product_id || !product_name || !carbon_points_cost || !quantity) {
            return res.status(400).json({
                success: false,
                message: '所有字段都是必填项'
            });
        }

        // 验证用户
        const user = await User.findById(user_id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: '用户不存在'
            });
        }

        // 验证商品
        const product = await Product.findById(product_id);
        if (!product) {
            return res.status(404).json({
                success: false,
                message: '商品不存在'
            });
        }

        // 检查商品库存
        if (product.quantity < quantity) {
            return res.status(400).json({
                success: false,
                message: '商品库存不足'
            });
        }

        // 检查用户碳积分
        const userPoints = await contractService.getCarbonPointBalance(user.blockchain_address);
        if (Number(userPoints) < carbon_points_cost) {
            return res.status(400).json({
                success: false,
                message: '用户碳积分不足'
            });
        }

        // 创建交易记录
        const newTransaction = new Transaction({
            user_id,
            product_id,
            product_name,
            carbon_points_cost,
            quantity,
            transaction_time: new Date()
        });

        // 扣除商品库存
        await Product.findByIdAndUpdate(
            product_id,
            { $inc: { quantity: -quantity } }
        );

        // 扣除用户碳积分
        await contractService.redeemProduct(
            user.blockchain_address,
            carbon_points_cost,
            product_name
        );

        const savedTransaction = await newTransaction.save();

        await session.commitTransaction();
        session.endSession();

        res.status(201).json({
            success: true,
            data: {
                transaction_id: savedTransaction._id,
                message: '交易创建成功'
            }
        });
    } catch (error) {
        await session.abortTransaction();
        session.endSession();

        console.error('创建交易失败:', error);
        res.status(500).json({
            success: false,
            message: '创建交易失败',
            error: error.message
        });
    }
});

// 删除交易记录
router.delete('/delete-transaction', async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        const { transaction_id } = req.body;

        // 验证交易ID格式
        if (!mongoose.Types.ObjectId.isValid(transaction_id)) {
            return res.status(400).json({
                success: false,
                message: '无效的交易ID'
            });
        }

        // 查找交易记录
        const transaction = await Transaction.findById(transaction_id);
        if (!transaction) {
            return res.status(404).json({
                success: false,
                message: '未找到指定的交易记录'
            });
        }

        // 查找相关的商品
        const product = await Product.findById(transaction.product_id);
        if (product) {
            // 恢复商品库存
            await Product.findByIdAndUpdate(
                transaction.product_id,
                { $inc: { quantity: transaction.quantity } }
            );
        }

        // 查找用户
        const user = await User.findById(transaction.user_id);
        if (user) {
            // 尝试恢复用户的碳积分
            try {
                await contractService.updateCarbonPoints(
                    user.blockchain_address,
                    transaction.carbon_points_cost
                );
            } catch (error) {
                console.error('恢复碳积分失败:', error);
                // 继续执行，但记录错误
            }
        }

        // 删除交易记录
        await Transaction.findByIdAndDelete(transaction_id);

        await session.commitTransaction();
        session.endSession();

        res.json({
            success: true,
            data: {
                transaction_id: transaction._id,
                product_name: transaction.product_name,
                carbon_points_restored: transaction.carbon_points_cost,
                quantity_restored: transaction.quantity,
                message: '交易记录删除成功，相关资源已恢复'
            }
        });
    } catch (error) {
        await session.abortTransaction();
        session.endSession();

        console.error('删除交易记录失败:', error);
        res.status(500).json({
            success: false,
            message: '删除交易记录失败',
            error: error.message
        });
    }
});

module.exports = router; 