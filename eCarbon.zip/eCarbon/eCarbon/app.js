const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const morgan = require('morgan');
require('dotenv').config();

const app = express();

// 中间件配置
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// 数据库连接
mongoose.connect(process.env.MONGODB_URI, {
    dbName: 'userManagement',             // 修改数据库名称
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB 连接成功'))
.catch(err => console.error('MongoDB 连接失败:', err));

// 导入路由
const userRoutes = require('./routes/user');
const contractRoutes = require('./routes/contract');
const carbonFootprintRoutes = require('./routes/carbonFootprint');
const activityRoutes = require('./routes/activity');
const taskTypeRoutes = require('./routes/taskType');
const userTaskRoutes = require('./routes/userTask');
const productRoutes = require('./routes/product');
const transactionRoutes = require('./routes/transaction');

// 使用路由
app.use('/api', userRoutes);
app.use('/api/contract', contractRoutes);
app.use('/api', carbonFootprintRoutes);
app.use('/api', activityRoutes);
app.use('/api', taskTypeRoutes);
app.use('/api', userTaskRoutes);
app.use('/api', productRoutes);
app.use('/api', transactionRoutes);

// 错误处理中间件
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        success: false,
        message: '服务器内部错误',
        error: err.message
    });
});

// 启动服务器
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`服务器运行在端口 ${PORT}`);
});

module.exports = app; 