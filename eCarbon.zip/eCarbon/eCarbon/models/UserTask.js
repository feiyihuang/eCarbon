const mongoose = require('mongoose');

const userTaskSchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    task_type_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'TaskType',
        required: true
    },
    task_name: {
        type: String,
        required: true,
        trim: true
    },
    reward: {
        type: Number,
        required: true,
        min: 0
    },
    progress: {
        type: Number,
        required: true,
        min: 0,
        max: 100
    },
    completed: {
        type: Boolean,
        default: false
    },
    rewarded: {
        type: Boolean,
        default: false
    },
    created_at: {
        type: Date,
        default: Date.now
    },
    updated_at: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('UserTask', userTaskSchema); 