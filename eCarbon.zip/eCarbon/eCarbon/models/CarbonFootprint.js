const mongoose = require('mongoose');

const carbonFootprintSchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    event_type: {
        type: String,
        required: true,
        enum: ['出行', '节能']  // 限制事件种类
    },
    carbon_emission: {
        type: Number,
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('CarbonFootprint', carbonFootprintSchema); 