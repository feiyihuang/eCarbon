const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

// 定义用户数据模型
const userSchema = new mongoose.Schema({
    phone_number: {
        type: String,
        required: true,
        unique: true,         // 确保手机号唯一
        trim: true,
        maxLength: 15
    },
    name: {
        type: String,
        required: true,
        trim: true,
        maxLength: 15
    },
    password: {
        type: String,
        required: true
    },
    blockchain_address: {
        type: String,
        required: true,
        unique: true
    },
    registration_date: {
        type: Date,
        default: Date.now
    },
    role: {
        type: Number,
        default: 0,  // 0: 普通用户, 1: 管理员
        enum: [0, 1]  // 只允许这两个值
    }
});

// 保存前对密码进行加密
userSchema.pre('save', async function(next) {
    if (this.isModified('password')) {
        this.password = await bcrypt.hash(this.password, 10);
    }
    next();
});

// 验证密码的方法
userSchema.methods.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('User', userSchema); 