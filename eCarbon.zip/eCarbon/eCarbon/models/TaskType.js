const mongoose = require('mongoose');

const taskTypeSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true,
        unique: true  // 确保任务名称唯一
    },
    reward: {
        type: Number,
        required: true,
        min: 0  // 确保奖励为非负数
    },
    created_at: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('TaskType', taskTypeSchema); 